export interface IStudent {
  id: number;
  name: string;
}
